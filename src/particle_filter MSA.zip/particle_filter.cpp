/*
 * particle_filter.cpp
 *
 *  Created on: Dec 12, 2016
 *      Author: Tiffany Huang
 */

#include <random>
#include <algorithm>
#include <iostream>
#include <numeric>

#include "particle_filter.h"

std::default_random_engine generator;
std::normal_distribution<double> distribution(0,1);

double bivariate_normal(double x, double y, double mu_x, double mu_y, double sig_x, double sig_y) {
  return exp(-((x-mu_x)*(x-mu_x)/(2*sig_x*sig_x) + (y-mu_y)*(y-mu_y)/(2*sig_y*sig_y))) / (2.0*3.14159*sig_x*sig_y);
} //* Soruce Slack channel #p-kidnapped-vehicle
 
void ParticleFilter::init(double x, double y, double theta, double std[]) {
	// TODO: Set the number of particles. Initialize all particles to first position (based on estimates of 
	//   x, y, theta and their uncertainties from GPS) and all weights to 1. 
	// Add random Gaussian noise to each particle.
	// NOTE: Consult particle_filter.h for more information about this method (and others in this file).
    num_particles = 50;
    weights.resize(num_particles);
    
    for (int i=0; i<num_particles; i++) {
      Particle particle_i;
      particle_i.x = x + std[0] * distribution(generator);
      particle_i.y = y + std[1] * distribution(generator);
      particle_i.theta = theta + std[2] * distribution(generator);
      particle_i.weight = 1.0f;
      weights[i] = 1.0f;
      particles.push_back(particle_i);   
    }
    is_initialized = true;
}

void ParticleFilter::prediction(double delta_t, double std_pos[], double velocity, double yaw_rate) {
	// TODO: Add measurements to each particle and add random Gaussian noise.
	// NOTE: When adding noise you may find std::normal_distribution and std::default_random_engine useful.
	//  http://en.cppreference.com/w/cpp/numeric/random/normal_distribution
	//  http://www.cplusplus.com/reference/random/default_random_engine/
    for (int i=0; i < num_particles; i++) {
      double theta = particles[i].theta;
      if (fabs(yaw_rate)>0.001){
        particles[i].x += velocity / yaw_rate*(sin(theta + yaw_rate * delta_t) - sin(theta))
                          + std_pos[0] * distribution(generator);
        particles[i].y += velocity / yaw_rate*(cos(theta)-cos(theta + yaw_rate * delta_t))
                          + std_pos[1] * distribution(generator);  
        particles[i].theta += yaw_rate * delta_t + std_pos[2] * distribution(generator);
      } else {
        particles[i].x += velocity * cos(theta) * delta_t + std_pos[0] * distribution(generator);
        particles[i].y += velocity * sin(theta) * delta_t + std_pos[1] * distribution(generator);
        particles[i].theta += yaw_rate * delta_t + std_pos[2] * distribution(generator);       
      }
    }

}

void ParticleFilter::dataAssociation(std::vector<LandmarkObs> predicted, std::vector<LandmarkObs>& observations) {
	// TODO: Find the predicted measurement that is closest to each observed measurement and assign the 
	//   observed measurement to this particular landmark.
	// NOTE: this method will NOT be called by the grading code. But you will probably find it useful to 
	//   implement this method and use it as a helper during the updateWeights phase.
    double distance_i;
  
    for (int i=0; i < observations.size(); i++) {
      double minimal_distance = 9999999;
      int associated_observation_id = -1;  
      
      for (int j=0; j < predicted.size(); j++) {    
        distance_i = dist(observations[i].x, observations[i].y, predicted[j].x, predicted[j].y);
        
        if (distance_i < minimal_distance){
          minimal_distance = distance_i;
          associated_observation_id = predicted[j].id;
        }
      }
      observations[i].id = associated_observation_id;
    }
}

void ParticleFilter::updateWeights(double sensor_range, double std_landmark[], 
		std::vector<LandmarkObs> observations, Map map_landmarks) {
	// TODO: Update the weights of each particle using a mult-variate Gaussian distribution. You can read
	//   more about this distribution here: https://en.wikipedia.org/wiki/Multivariate_normal_distribution
	// NOTE: The observations are given in the VEHICLE'S coordinate system. Your particles are located
	//   according to the MAP'S coordinate system. You will need to transform between the two systems.
	//   Keep in mind that this transformation requires both rotation AND translation (but no scaling).
	//   The following is a good resource for the theory:
	//   https://www.willamette.edu/~gorr/classes/GeneralGraphics/Transforms/transforms2d.htm
	//   and the following is a good resource for the actual equation to implement (look at equation 
	//   3.33. Note that you'll need to switch the minus sign in that equation to a plus to account 
	//   for the fact that the map's y-axis actually points downwards.)
	//   http://planning.cs.uiuc.edu/node99.html
  
    weights.clear();
    
    //convert observations to map coordinates
  
    for (int i=0; i < num_particles; i++) {
      double theta = particles[i].theta;
      std::vector<LandmarkObs> observations_converted;
      
      for (int j=0; j < observations.size(); j++){
        LandmarkObs observation_converted;
        observation_converted.x = observations[j].x * cos(theta) - observations[j].y * sin(theta) + particles[i].x;
        observation_converted.y = observations[j].x * sin(theta) + observations[j].y * cos(theta) + particles[i].y;
        
        observation_converted.id = -1;
        observations_converted.push_back(observation_converted);
      } 
      

      
      // Find landmarks in particle sensor range
      std::vector<LandmarkObs> landmarks_in_range;
      
      for (int j=0; j < map_landmarks.landmark_list.size(); j++) {
        double distance = dist(particles[i].x, particles[i].y, 
                               map_landmarks.landmark_list[j].x_f, map_landmarks.landmark_list[j].y_f);
        
        if (distance <= sensor_range){
          LandmarkObs landmark_in_range;
          landmark_in_range.id = map_landmarks.landmark_list[j].id_i;
          landmark_in_range.x = map_landmarks.landmark_list[j].x_f;
          landmark_in_range.y = map_landmarks.landmark_list[j].y_f;
          
          landmarks_in_range.push_back(landmark_in_range);
        }
      }
      
      dataAssociation(landmarks_in_range, observations_converted);
      
      double probability = 1;
      double probability_j;
      
      for (int j = 0; j < landmarks_in_range.size(); j++){
        for (int k = 0; k< observations_converted.size(); k++){
          if (landmarks_in_range[j].id == observations_converted[k].id) { 
            probability_j = bivariate_normal(landmarks_in_range[j].x, landmarks_in_range[j].y,
                                  observations_converted[k].x, observations_converted[k].y,
                                 std_landmark[0], std_landmark[1]);
            probability *= probability_j;
          }
        }
      }
      
      weights.push_back(probability);
      particles[i].weight = probability;
    }
}

void ParticleFilter::resample() {
	// TODO: Resample particles with replacement with probability proportional to their weight. 
	// NOTE: You may find std::discrete_distribution helpful here.
	//   http://en.cppreference.com/w/cpp/numeric/random/discrete_distribution

    std::discrete_distribution<int> weights_distribution(weights.begin(), weights.end());
    std::vector<Particle> resampled_particles;

    for(int i=0;i<num_particles;i++){
				Particle particle_i = particles[weights_distribution(generator)];
        resampled_particles.push_back(particle_i);
    }
    particles = resampled_particles;
}

void ParticleFilter::write(std::string filename) {
	// You don't need to modify this file.
	std::ofstream dataFile;
	dataFile.open(filename, std::ios::app);
	for (int i = 0; i < num_particles; ++i) {
		dataFile << particles[i].x << " " << particles[i].y << " " << particles[i].theta << "\n";
	}
	dataFile.close();
}
